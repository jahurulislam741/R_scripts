
# This script defines a function to generate prompts as PDF pages from a text file containing the words
# The function has 
    # one required argument: a text file listing the prompt words, one per word
    # three optional arguments: 
        # 1) 'preceding_text' (a string, default = 'say')
        # 2) 'following_text' (a string, default = 'again')
        # 1) 'font_size' (a number, default = 15) 
# The output is a PDF file with the words in carrier phrases on individual pages
# Works with Bangla text too (typed with Avro); but, on Linux Ubuntu only (b/c Windows is having issues with cairo_pdf)

make_prompts <- function(filename, preceding_text = 'say', following_text = 'again', font_size = 15){
  library(ggplot2)
  # load the list of words from the source file
  data <- read.delim(filename, header = F, encoding = 'UTF-8') # no header in the source file
  names(data) <- c('word') # (re)name the column
  list_of_words <- sample(data$word) # randomize the words (as a new vector)
  
  # make plots
  cairo_pdf('prompts.pdf', h = 5, w = 8, onefile = T, family = 'sans')
  for (w in list_of_words) { # loop through the word list
    x <- c(1)
    y <- c(1)
    phrase <- paste(preceding_text, w, following_text, sep = ' ') # create the phrase to be printed
    df <- as.data.frame(cbind(x,y,phrase)) # create a dataframe for plotting purpose
    p <- ggplot(df, aes(x, y, label = phrase)) +
      geom_text(size = font_size) +
      theme_minimal() +
      theme(axis.text = element_blank(),
            axis.ticks = element_blank(),
            axis.title.x = element_blank(),
            axis.title.y = element_blank(),
            element_line( linetype = 'blank')
      )
    print(p)
  }
  dev.off()
}

# define the text to precede and follow the prompt words (the carrier phrases) 
preceding_text <- 'say'
following_text <- 'again'
# preceding_text <- 'এবারে'
# following_text <- 'বলুন'

filename <- 'word_list.txt'
make_prompts(filename)



