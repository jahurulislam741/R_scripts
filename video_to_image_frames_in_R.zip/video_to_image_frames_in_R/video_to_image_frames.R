
# get input filenames and paths
input_dir <- '1_input_video_files'
filepaths <- list.files(input_dir, full.names = T)
filenames <- list.files(input_dir, full.names = F)
basenames <- sub("\\.\\w+$", "", filenames) # remove file extensions

# set up output directory
output_dir <- '2_extracted_frames'
unlink(output_dir, recursive = T) # delete previous version if exists
dir.create(output_dir, showWarnings = F)

for (i in 1:length(filepaths)) {
  # create subdir for current clip
  sub_dir = paste0(output_dir,'/',basenames[i])
  dir.create(sub_dir, showWarnings = F)
  
  # convert video to image frames
  av::av_video_images(filepaths[i], destdir = sub_dir, format = "png", fps = 30)
}

